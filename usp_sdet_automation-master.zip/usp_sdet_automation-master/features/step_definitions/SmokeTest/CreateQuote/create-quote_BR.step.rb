include RSpec::Matchers


Given("access USP as a valid customer") do
  @LandingPage = LandingPage.new
  @LandingPage.page_search_by_customer
  @LandingPage.selectRole_BR
  @CustomerInformationPage = CustomerInformationPage.new
  @CustomerInformationPage.system_menu
end

When("a product is added inside of cart proceeding with the creation") do
  @ConfigCurrentPage = ConfigCurrentPage.new
  @ConfigCurrentPage.proceed_create_quote
  @DetailCartPage = DetailCartPage.new
  @DetailCartPage.create_quote
end

Then("is generated a new quote number") do
  @DetailCartPage.get_quote_number
  @CustomerInformationPage.search_menu
  @LandingPage.search_by_quote_br
  @LandingPage.validation_customer_number
end