include RSpec::Matchers


Given("a quote has be created") do
  @LandingPage = LandingPage.new
  @LandingPage.search_by_quote_br
  @LandingPage.selectRole_BR
end

When("search this quote and proceed to create order") do
  @CreateOrderPage = CreateOrderPage.new
  @CreateOrderPage.create_order
end

Then("a new Order number is generated") do
  pending # Write code here that turns the phrase above into concrete actions
end