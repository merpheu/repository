include RSpec::Matchers

Given("USP home page is opened correctly") do
    @LandingPage = LandingPage.new
    @LandingPage.validation_access_landing_page
  end
  
  When("a customer MX_23 is created") do
    @LandingPage.menu_create_customer_page 
    @CreateCustomerNew = CreateCustomerNew.new
    @CreateCustomerNew.create_customer_mx_23
    @CustomerInformationPage = CustomerInformationPage.new
    @CustomerInformationPage.get_dcn_number
    @CustomerInformationPage.search_menu
    @LandingPage.search_by_customer_mx
  end

  When("a customer MX_03 is created") do
    @LandingPage.menu_create_customer_page
    @CreateCustomerNew = CreateCustomerNew.new
    @CreateCustomerNew.create_customer_mx_03
    @CustomerInformationPage = CustomerInformationPage.new
    @CustomerInformationPage.get_dcn_number
    @CustomerInformationPage.search_menu
    @LandingPage.search_by_customer_mx
  end
  
  Then("must show the DCN number on screen customer info page") do
    @LandingPage.validation_customer_number
  end