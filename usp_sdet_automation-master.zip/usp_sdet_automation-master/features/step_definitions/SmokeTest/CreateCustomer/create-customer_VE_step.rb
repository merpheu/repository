include RSpec::Matchers

When("a customer VE is created") do
  @LandingPage.menu_create_customer_page
  @CreateCustomerNew = CreateCustomerNew.new
  @CreateCustomerNew.create_customer_ve
  @CustomerInformationPage = CustomerInformationPage.new
  @CustomerInformationPage.get_dcn_number
  @CustomerInformationPage.search_menu
  @LandingPage.search_by_customer_ve
end