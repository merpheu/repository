include RSpec::Matchers

Given("USP home page is opened") do
  @LandingPage = LandingPage.new
  @LandingPage.validation_access_landing_page
end

When("a customer is created") do
  @LandingPage.menu_create_customer_page
  @CreateCustomerNew = CreateCustomerNew.new
  @CreateCustomerNew.create_customer_br
  @CustomerInformationPage = CustomerInformationPage.new
  @CustomerInformationPage.get_dcn_number
  @CustomerInformationPage.search_menu
  @LandingPage.search_by_customer
end

Then("must show the DCN number on screen") do
  @LandingPage.validation_customer_number
end