
Dado("que o usuário tenha acesso no USP") do
  visit "www.google.com"
end

Quando("acessamos a <url> referente ao USP") do |url|
    url = "http://u4vmuspuisitg21.olqa.preol.dell.com/"
    visit @url
end

Quando("selecionarmos dentro do menu superior a opção <tools> e o submenu <bulkprocessing>") do |tools,bulkprocessing|
  tools = "menu tool"
  bulkprocessing = "submenu bulk processing"
  put @tools
  put @bulkprocessing
end

Então("o sistema deve mostrar a pagina do Bulk Processing") do
  put "teste OK"
end