require 'capybara'
require 'capybara/cucumber'
require 'capybara/rspec'
require 'selenium/webdriver'
require 'site_prism'
require 'faker'
require 'rubygems'
require 'rspec'

 Before() do
   visit CONFIG['url']
 end

After do |scenario|
  scenario_name = scenario.name.gsub(/[^A-Za-z0-9 ]/, '')
  scenario_name = scenario_name.gsub(' ', '_').downcase!
  screenshot = page.save_screenshot("log/screenshots/#{scenario_name}.png")
  shot = Base64.encode64(File.open(screenshot, "rb").read)
  embed(shot, 'image/png', 'Evidence')
end

 After do
   Capybara.current_session.driver.quit
 end
