require 'capybara'
require 'capybara/cucumber'
require 'capybara/rspec'
require 'selenium/webdriver'
require 'site_prism'
require 'faker'
require 'rubygems'
require 'rspec'

ENVIRONMENT = ENV['ENVIRONMENT']
CONFIG = YAML.load_file(File.dirname(__FILE__) + "/environments/#{ENVIRONMENT}.yml")
CUSTOM = YAML.load_file(File.dirname(__FILE__) + "/config.yml")

# Capybara.register_driver :selenium_chrome_headless do |app|
#   Capybara::Selenium::Driver.load_selenium
#   browser_options = ::Selenium::WebDriver::Chrome::Options.new.tap do |opts|
#     opts.args << "--headless"
#     opts.args << "--disable-gpu" if Gem.win_platform?
#     opts.args << "--no-sandbox"
#     opts.args << "--disable-site-isolation-trials"
#   end
#   Capybara::Selenium::Driver.new(app, browser: :chrome, options: browser_options)
# end
#
# Capybara.configure do |config|
#   config.default_driver = :selenium_chrome_headless
#   config.default_max_wait_time = 45
# end


# --------------------IE--------------------

Capybara.register_driver :ie do |app|
  caps = Selenium::WebDriver::Remote::Capabilities.internet_explorer
  caps["ignoreProtectedModeSettings"] = true
  Capybara::Selenium::Driver.new(app, :browser => :internet_explorer, :desired_capabilities => caps)
end

@browser = Capybara.default_driver = :ie
@browser = Capybara.default_max_wait_time = 60
@browser = Capybara.page.current_window.resize_to(1280, 1204)