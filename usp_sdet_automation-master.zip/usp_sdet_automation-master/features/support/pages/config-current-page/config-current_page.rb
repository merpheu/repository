class ConfigCurrentPage < SitePrism::Page
  include Capybara::DSL

  #ConfigMenu
  element :hrefImportOrderCode, "a[href*='E-Value']"
  element :inputOrderCode, "#evaluetext2"
  element :inputProceedConfig, "#proceed_config"

  #Item Details
  element :input_details_cart, "#btnDetailCart"

  def proceed_create_quote()
    within_window(windows.last) do
      hrefImportOrderCode.click
      inputOrderCode.set(CUSTOM['Order_code02'])
      inputProceedConfig.click
      input_details_cart.click
    end
  end

end


