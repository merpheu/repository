class CreateOrderPage < SitePrism::Page
  include Capybara::DSL

  #Customer Info
  element :input_checkbox_ship_address, "input[id='chkShipInfo']", visible: false
  element :input_checkbox_bill_address, "input[id='chkBillInfo']", visible: false

  #Proceed to Payment
  element :input_button_proceed_payment, "#btnProceedToPayment"
  element :input_button_submit_order, "#btnOrderSubmit"


  def initialize
    @DetailCartPage = DetailCartPage.new
  end

  def create_order
    @DetailCartPage.create_order_button

    within_window(windows.last) do
      input_checkbox_bill_address.click
      input_checkbox_ship_address.click
      input_button_proceed_payment.click
      input_button_submit_order.click
    end
  end

  def get_quote_number
    within_window(windows.last) do
      sleep 5
      $quote_number = find(:xpath, "//*[@id='form1']/div[8]/div[2]", visible: false).text
      puts $quote_number
    end
  end

end