class CreateCustomerNew < SitePrism::Page
  include Capybara::DSL

  #Element for Brazil
  element :selectBuid, "#buid"
  element :selectRoles, "#roles"
  element :selectCustomerClass, "#customerClass"
  element :textFedTax_Id, "#fedTax_Id" 
  element :serasaSearchButton, "#serasaSearchButton"
  element :textStreetAddress1, "#streetAddress1"
  element :textAddressNumber, "#number"
  element :textAddressComplement, "#complement"
  element :textAddressCity, "#city"
  element :selectStates, "#statesSel"
  element :textAddressZipCode, "#zipCode"
  element :textEmailAddress, "#txtEmailAddress"
  element :textDayPhoneNumber, "#DayPhoneNumber"
  element :selectPaymtCodeId, "#paymtCodeId"
  element :buttonCreateCustomer, "#btnCreateCustomer"
  element :divProgress, ".progress"

  #Element for Argentina

   element :textfedTax_Id, "#fedTax_Id"
   element :selecttax_Category,"#tax_Category"

  #Element for Mexico
 
    element :textCompany, "#companyName"
    element :textfirstName, "#firstName"
    element :textlastName, "#lastName"
    element :textprefixId, "#prefixId"   
    element :selecttaxTypeId, "#taxType_Id"
    element :textfederalTax_MX, "#fedTax_Id"
    element :textInvoiceEmailAddresses, "#InvoiceEmailAddresses"

  def customer_information_data()
    @company_name = Faker::Name.name
    @first_name = Faker::Name.first_name
    @last_name = Faker::Name.last_name
    @name_prefix = Faker::Name.prefix

    textCompany.set(@company_name)
    textfirstName.set(@first_name)
    textlastName.set(@last_name)
    textprefixId.set(@name_prefix)
  end

  def address_data()
    @address = Faker::Address.street_name
    @city = Faker::Address.city

    textStreetAddress1.set(@address)
    textAddressCity.set(@city)
  end

  def contact_details_data()
    @email = Faker::Internet.email
    @phoneNumber = Faker::Number.number(15)

    textEmailAddress.set(@email)
    textDayPhoneNumber.set(@phoneNumber)
  end

  def create_customer_br()
    selectBuid.select(CUSTOM['buid_BR'])
    selectRoles.select(CUSTOM['role_BR01'])
    selectCustomerClass.select(CUSTOM['customerClass_BR'])
    textFedTax_Id.set(CUSTOM['fedTax_Id_BR_CPF_01']) 
    serasaSearchButton.click
    textStreetAddress1.set('Quadra 48')
    textAddressNumber.set('75')
    textAddressComplement.set('Setor Leste')
    textAddressCity.set('BRASILIA')
    selectStates.select('DISTRITO FEDERAL')
    textAddressZipCode.set('72455480')
    contact_details_data
    selectPaymtCodeId.select('American Express')
    wait_until_buttonCreateCustomer_visible
    buttonCreateCustomer.click
  end

  def create_customer_ar()

    @address = Faker::Address.street_name
    @city = Faker::Address.city

    selectBuid.select(CUSTOM['buid_AR'])
    selectRoles.select(CUSTOM['role_AR'])
    selectCustomerClass.select(CUSTOM['customerClass_AR'])
    textfedTax_Id.set('30-71103999-2')
    selecttax_Category.select(CUSTOM['taxCategory'])
    customer_information_data
    textStreetAddress1.set(@address)
    textAddressCity.set(@city)
    textAddressZipCode.set('540000')
    contact_details_data
    selectPaymtCodeId.select('American Express')
    buttonCreateCustomer.click
  end

  def create_customer_mx_23()

    @phone_number_mx = Faker::Number.number(16)
    @email_mx = Faker::Internet.email

    selectBuid.select(CUSTOM['buid_mx_23'])
    selectRoles.select(CUSTOM['role_mx_23'])
    selectCustomerClass.select(CUSTOM['customer_class_mx_23'])
    textfederalTax_MX.set(CUSTOM['fed_tax_id_mx_23'])
    selecttaxTypeId.select(CUSTOM['tax_type_id_mx_23'])
    customer_information_data
    address_data
    selectStates.select('AGUASCALIENTES')
    textAddressZipCode.set('72010020')
    textDayPhoneNumber.set(@phone_number_mx)
    textEmailAddress.set(@email_mx)
    selectPaymtCodeId.select('American Express')
    textfederalTax_MX.click
    textCompany.click
    buttonCreateCustomer.click
  end

  def create_customer_mx_03()

    @phone_number_mx = Faker::Number.number(16)
    @email_mx = Faker::Internet.email

    selectBuid.select(CUSTOM['buid_mx_23'])
    selectRoles.select(CUSTOM['role_mx_23'])
    selectCustomerClass.select(CUSTOM['customer_class_mx_23'])
    textfederalTax_MX.set(CUSTOM['fed_tax_id_mx_23'])
    selecttaxTypeId.select(CUSTOM['tax_type_id_mx_23'])
    customer_information_data
    address_data
    selectStates.select('AGUASCALIENTES')
    textAddressZipCode.set('72010020')
    textDayPhoneNumber.set(@phone_number_mx)
    textEmailAddress.set(@email_mx)
    selectPaymtCodeId.select('American Express')
    textfederalTax_MX.click
    textCompany.click
    buttonCreateCustomer.click
  end

  def create_customer_cl()

    @phone_number_mx = Faker::Number.number(16)
    @email_mx = Faker::Internet.email

    selectBuid.select(CUSTOM['buid_cl'])
    selectRoles.select(CUSTOM['role_cl'])
    selectCustomerClass.select(CUSTOM['customer_class_cl'])
    textfederalTax_MX.set(CUSTOM['fed_tax_id_cl'])
    customer_information_data
    address_data
    textAddressZipCode.set('72010020')
    textDayPhoneNumber.set(@phone_number_mx)
    textEmailAddress.set(@email_mx)
    selectPaymtCodeId.select('American Express')
    textfederalTax_MX.click
    textCompany.click
    buttonCreateCustomer.click
  end

  def create_customer_col()

    @phone_number_mx = Faker::Number.number(16)
    @email_mx = Faker::Internet.email

    selectBuid.select(CUSTOM['buid_col'])
    selectRoles.select(CUSTOM['role_col'])
    selectCustomerClass.select(CUSTOM['customer_class_col'])
    textfederalTax_MX.set(CUSTOM['fed_tax_id_col'])
    customer_information_data
    address_data
    textAddressZipCode.set('72010020')
    textDayPhoneNumber.set(@phone_number_mx)
    textEmailAddress.set(@email_mx)
    selectPaymtCodeId.select('American Express')
    textfederalTax_MX.click
    textCompany.click
    buttonCreateCustomer.click
  end

  def create_customer_pe()

    @phone_number_mx = Faker::Number.number(16)
    @email_mx = Faker::Internet.email

    selectBuid.select(CUSTOM['buid_pe'])
    selectRoles.select(CUSTOM['role_pe'])
    selectCustomerClass.select(CUSTOM['customer_class_pe'])
    textfederalTax_MX.set(CUSTOM['fed_tax_id_pe'])
    customer_information_data
    address_data
    textAddressZipCode.set('72010020')
    textDayPhoneNumber.set(@phone_number_mx)
    textEmailAddress.set(@email_mx)
    selectPaymtCodeId.select('Buy and Try')
    textfederalTax_MX.click
    textCompany.click
    buttonCreateCustomer.click
  end

  def create_customer_ve()

    @phone_number_mx = Faker::Number.number(16)
    @email_mx = Faker::Internet.email

    selectBuid.select(CUSTOM['buid_ve'])
    selectRoles.select(CUSTOM['role_ve'])
    selectCustomerClass.select(CUSTOM['customer_class_ve'])
    textfederalTax_MX.set(CUSTOM['fed_tax_id_ve'])
    customer_information_data
    address_data
    textAddressZipCode.set('72010020')
    textDayPhoneNumber.set(@phone_number_mx)
    textEmailAddress.set(@email_mx)
    selectPaymtCodeId.select('American Express')
    textfederalTax_MX.click
    textCompany.click
    buttonCreateCustomer.click
  end

end