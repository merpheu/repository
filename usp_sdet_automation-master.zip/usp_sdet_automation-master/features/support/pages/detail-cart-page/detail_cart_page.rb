class DetailCartPage < SitePrism::Page
  include Capybara::DSL

  #Detail Cart page
  element :input_btnQuote, "#btnQuote"

  #Save Quote page
  element :select_payment, "select[id='ddlPaymentMethod']"
  element :input_radio_yes_nf, "input[id='ryes']", visible: false
  element :input_product_be_used, "input[id='rbUltimateDes']", visible: false
  element :img_contact_details, "img[id='imgExpandCollapse']", visible: false
  element :input_redflags_yes, "input[id='RedFlagInfoYes']", visible: false
  element :input_reset, "input[value='Reset']", visible: false
  element :input_ok, "input[id='Quote_Button']", visible: false
  element :input_cancel, "input[value='Cancel']", visible: false

  #Create order
  element :input_btn_order, "#btnOrder"

  def create_quote

    within_window(windows.last) do
      input_btnQuote.click
    end

    within_window(->{ page.title == 'Save Quote' }) do
      input_txt_primary_sales_rep = find('#txtPrimarySalesRep', visible: false)
      page.execute_script("arguments[0].setAttribute('value', '9999')", input_txt_primary_sales_rep)
      select "Prepaid Check", :from => "ddlPaymentMethod", visible: false
      input_radio_yes_nf.click
      txt_quote_notes = find('#QuoteNotes', visible: false)
      page.execute_script("arguments[0].setAttribute('value', 'Test 123')", txt_quote_notes)
      select "Home", :from => "ddlProducts", visible: false
      input_ok.click
      sleep 10
    end
  end

  def get_quote_number
    within_window(windows.last) do
      sleep 5
      $quote_number = find(:xpath, "//*[@id='form1']/div[8]/div[2]", visible: false).text
      puts $quote_number
    end
  end

  def create_order_button
    within_window(windows.last) do
      input_btn_order.click
    end
  end
end
