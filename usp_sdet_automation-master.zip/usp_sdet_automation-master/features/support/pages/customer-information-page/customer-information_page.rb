class CustomerInformationPage < SitePrism::Page
  include Capybara::DSL

  #menu
  element :hrefMenuProduct, "a.dropdown-toggle.top_link", :text => "Product"
  element :hrefMenuSearch, "a[href$='Search']"
  element :hrefMenuSystem, "a[href$='CurrentConfig']"

  #Customer information
  element :h3PageTitle, ".page-title-font", :text => "Customer Information"
  element :aInfo, "a", :text => "Info"


  def get_dcn_number()
    sleep 15
    within_window(windows.last) do
      $dcnNumber = find(:xpath, "//*[@id='customerInformationBlock']/div[2]/div[2]/p[1]", visible: false).text
      puts $dcnNumber
      #$omsNumber = find(:xpath, "//*[@id='customerInformationBlock']/div[2]/div[2]/p[2]").text
    end
  end

  def search_menu()
    within_window(windows.last) do
      hrefMenuProduct.click
      hrefMenuSearch.click
    end
  end

  def system_menu()
    within_window(windows.last) do
      hrefMenuProduct.click
      hrefMenuSystem.click
    end
  end

end