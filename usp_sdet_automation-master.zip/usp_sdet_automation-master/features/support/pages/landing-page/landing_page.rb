class LandingPage < SitePrism::Page
  include Capybara::DSL

  #menu
  element :menuCustumer, "#navbarDropdownMenu1"
  element :dropdownCreateNew, "a[href$='New']"

  #search
  element :inputOmsDcn, "#customer"
  element :selectBuidCountry, "#buidSelection"
  element :input_quote, "#quote"
  element :buttonSearch, "#searchBtn"
  element :divLoadingModal, "#loadingModal"

  #search old
  element :input_dcn_old, "#viewModel_SearchRequest_CesrID"
  element :select_buid_country_old, "#viewModel_SearchRequest_BusinessUnitID"
  element :input_btn_search, "#btnSearch"
  element :div_dialog, "#divDialog"

  #customer Details
  element :divCustomerResults, "#customer-results"
  element :tdCustomerResults, ".sorting_1"

  #select a role
  element :labelRadioSelectRole, "label[for='customRadio20']", visible: false
  element :buttonConfirmaRole, "#btnSelectRole"

  def validation_access_landing_page
    expect(page).to have_css("label", :text => "Search By")
  end

  def menu_create_customer_page
    menuCustumer.click
    dropdownCreateNew.click
  end

  def search_by_customer
    within_window(windows.last) do
      inputOmsDcn.set($dcnNumber)
      selectBuidCountry.select('Brazil')
      buttonSearch.click
      wait_until_divLoadingModal_invisible
    end
  end

  def page_search_by_customer
    inputOmsDcn.set($dcnNumber)
    selectBuidCountry.select('Brazil')
    buttonSearch.click
    wait_until_divLoadingModal_invisible
  end

  def selectRole_BR
    labelRadioSelectRole.click
    buttonConfirmaRole.click
  end

  def search_by_customer_ar
    within_window(windows.last) do
      inputOmsDcn.set($dcnNumber)
      selectBuidCountry.select('Argentina')
      buttonSearch.click
      wait_until_divLoadingModal_invisible
    end
  end

  def search_by_customer_mx
    within_window(windows.last) do
      inputOmsDcn.set($dcnNumber)
      selectBuidCountry.select('Mexico')
      buttonSearch.click
      wait_until_divLoadingModal_invisible
    end
  end

  def search_by_customer_cl
    within_window(windows.last) do
      inputOmsDcn.set($dcnNumber)
      selectBuidCountry.select('Chile')
      buttonSearch.click
      wait_until_divLoadingModal_invisible
    end
  end

  def search_by_customer_col
    within_window(windows.last) do
      inputOmsDcn.set($dcnNumber)
      selectBuidCountry.select('Colombia')
      buttonSearch.click
      wait_until_divLoadingModal_invisible
    end
  end

  def search_by_customer_pe
    within_window(windows.last) do
      inputOmsDcn.set($dcnNumber)
      selectBuidCountry.select('Peru')
      buttonSearch.click
      wait_until_divLoadingModal_invisible
    end
  end

  def search_by_customer_ve
    within_window(windows.last) do
      inputOmsDcn.set($dcnNumber)
      selectBuidCountry.select('Venezuela')
      buttonSearch.click
      wait_until_divLoadingModal_invisible
    end
  end

  def search_by_quote_br
    within_window(windows.last) do
      input_quote.set($quote_number)
      #input_quote.set("1005376278824")
      selectBuidCountry.select('Brazil')
      buttonSearch.click
      wait_until_divLoadingModal_invisible
    end
  end

  def validation_customer_number
    within_window(windows.last) do
      expect(tdCustomerResults.text()).to start_with "#{$dcnNumber}"
    end
  end

end