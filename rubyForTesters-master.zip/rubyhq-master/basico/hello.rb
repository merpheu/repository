puts 'Olá Ruby!'
