


carro = Hash[nome: 'Civic', marca: 'Honda', cor: 'Vermelho']

puts carro[:marca]

carro[:modelo] = 'SI'

puts carro