

#numero1 = 0
#numero2 = 0
#total = 0

#puts 'Informe o número 1:'
#numero1 = gets.chomp.to_i

#puts 'Informe o número 2:'
#numero2 = gets.chomp.to_i

#total = numero1 + numero2
#total = numero1 - numero2
#total = numero1 * numero2
#total = numero1 / numero2
#puts total

# Operadores de Comparaçao

v1 = 10
v2 = 10

# maior que >
# meno que <
# maior ou igual >=
# menor ou igual <=
# diferente !=
# igual a ==
# igual eql?

puts v1.eql?(v2)
